create
    definer = root@localhost procedure asignareUserMaterie(IN p_id_user int, IN p_id_materie int)
BEGIN
    SET @exista = (SELECT count(id_user) FROM users_materii WHERE id_user = p_id_user AND p_id_materie = id_materie);
    IF @exista = 0 OR @exista is null THEN
        INSERT INTO users_materii VALUES (p_id_user, p_id_materie, 0);
    END IF;
END;

