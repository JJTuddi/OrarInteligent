create definer = root@localhost view vmaterii as
select `m`.`id_materie`          AS `id_materie`,
       `m`.`denumire_materie`    AS `denumire_materie`,
       `m`.`prescurtare`         AS `prescurtare`,
       `m`.`zi`                  AS `zi`,
       `m`.`ora_inceput`         AS `ora_inceput`,
       `m`.`durata`              AS `durata`,
       `m`.`numar_credite`       AS `numar_credite`,
       `m`.`nume_profesor`       AS `nume_profesor`,
       `a`.`denumire_activitate` AS `denumire_activitate`
from (`orar`.`materii` `m`
         join `orar`.`activitati` `a`)
where (`m`.`id_tip_activitate` = `a`.`id_activitate`);

