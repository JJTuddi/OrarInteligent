create
    definer = root@localhost function inregistrare(p_email varchar(128), p_username varchar(16), p_parola varchar(16),
                                                   p_nume varchar(32), p_prenume varchar(64)) returns int
BEGIN
    SET @exista = (SELECT count(*) FROM users WHERE email = p_email OR username = p_username);
    IF @exista = 0 THEN
        INSERT INTO users (email, username, parola, nume, prenume) VALUES (p_email, p_username, p_parola, p_nume, p_prenume);
    END IF;
    RETURN @exista;
END;

